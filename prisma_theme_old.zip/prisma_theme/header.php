<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
<meta name="keywords" content="" />
<meta name="description" content="" />

<title><?php wp_title('&laquo;', true, 'right'); ?></title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800&amp;subset=cyrillic" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo( 'stylesheet_url' ); ?>" />

<link rel="icon" href="<?php bloginfo( 'template_url' ); ?>/img/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="<?php bloginfo( 'template_url' ); ?>/img/favicon.ico" type="image/x-icon">

<script type="text/javascript" src="<?php bloginfo( 'template_url' ); ?>/js/script.js"></script>

<?php wp_head(); ?>

</head>
<body>
			<?php include(TEMPLATEPATH."/left.php");?>
	<header>
		<div class="logo no_mob"><a href="/"><img src="<?php bloginfo( 'template_url' ); ?>/img/logo_1.png" align="absmiddle"></a></div>
		<div class="all_mob"><a href="/"><img src="<?php bloginfo( 'template_url' ); ?>/img/moblogo.png" align="absmiddle"></a></div>
			<?php include(TEMPLATEPATH."/phone.php");?>
		<div class="menu_1 flex-list">
<?php wp_nav_menu('menu=top_menu_1'); ?>
		</div>
		<?php include(TEMPLATEPATH."/mob_menu.php");?>
		<div class="menu_2 flex-list">
<?php wp_nav_menu('menu=top_menu_2'); ?>
		</div>
	</header>
<br clear="all">

