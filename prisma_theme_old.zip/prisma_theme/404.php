<?php include(TEMPLATEPATH."/header_2.php");?>

	<article>
		<div class="wrapper">

<p>К сожалению страница не найдена</p>
<p><a href="/">Вернуться на главную</a></p>

		</div>
	</article>

<?php get_footer(); ?>