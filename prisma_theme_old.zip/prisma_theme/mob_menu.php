		<div class="menu_1_mob">
		<a onclick="banner(1);" class="openpopup" rel="feedback"><img src="/wp-content/themes/prisma_theme/img/feedback.png" /></a>
		<a onclick="menu(1)" class="openmenu"><img src="/wp-content/themes/prisma_theme/img/menu_list/burger.png" /></a>
		</div>
		<div class="mobilemenu" id="menumob">		
	<div class="line">
		<a onclick="menu(0)" class="closemenu"><img src="/wp-content/themes/prisma_theme/img/closemenu.png" /></a>
		МЕНЮ
	</div>
	<div class="mob-menu-inner">
		<div class="flex-list">
<?php wp_nav_menu('menu=top_menu_1'); ?>
		</div>
		<a onclick="submenu(1)" id="sub1" class="section-toggle">Направления деятельности</a>
		<a onclick="submenu(0)" id="sub2" class="section-toggle" style="display: none;">Направления деятельности</a>
	</div>
	<div class="section-mob-menu" id="submob">
	<table cellpadding="0" cellspacing="0" class="menu-list">
		<tr>
			<td><a href="/services/onlayn-kursy/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/1.png" align="absmiddle"></a><a href="/services/onlayn-kursy/">Онлайн курсы</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/podgotovka-k-shkole/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/2.png" align="absmiddle"></a><a href="/services/podgotovka-k-shkole/">Подготовка к школе</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/holidays/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/3.png" align="absmiddle"></a><a href="/services/holidays/">Каникулы</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/robototekhnika/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/4.png" align="absmiddle"></a><a href="/services/robototekhnika/">Робототехника</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/tekhnicheskie-inzhenernye-it/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/5.png" align="absmiddle"></a><a href="/services/tekhnicheskie-inzhenernye-it/">Инженерные и IT</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/zanyatiya-dlya-shkolnikov/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/6.png" align="absmiddle"></a><a href="/services/zanyatiya-dlya-shkolnikov/">Клуб дневного пребывания</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/mini-sad/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/7.png" align="absmiddle"></a><a href="/services/mini-sad/">Мини-сад</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/prazdnik-v-prizme/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/8.png" align="absmiddle"></a><a href="/services/prazdnik-v-prizme/">Праздник в Призме</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/rannee-razvitie/" class="img"><img src="/wp-content/themes/prisma_theme//img/menu_list/9.png" align="absmiddle"></a><a href="/services/rannee-razvitie/">Раннее развитие</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/creative/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/10.png" align="absmiddle"></a><a href="/services/creative/">Творческие занятия </a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/izuchenie-yazykov/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/11.png" align="absmiddle"></a><a href="/services/izuchenie-yazykov/">Языковые группы</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/studiya-spektr/" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/12.png" align="absmiddle"></a><a href="/services/studiya-spektr/">Индивидуально</a>
			</td>
		</tr>
		<tr>
			<td><a href="/services/?age=5" class="img"><img src="/wp-content/themes/prisma_theme/img/menu_list/13.png" align="absmiddle"></a><a href="/services/?age=5">Родительский клуб</a>
			</td>
		</tr>
	</table>
	</div>
	<div class="right">
		<a href="tel:+7 995 500 2442" class="phone" style="color: black;">+7 995 500 2442</a><br />
		<br />
		<a onclick="banner(1);" class="openpopup" rel="feedback">Заказать обратный звонок</a>
	</div>
</div>
