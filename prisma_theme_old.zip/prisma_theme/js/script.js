﻿function banner(fl) {
	if(fl>0){
		document.getElementById("ban").style.display = "block";
	}
	else{
		document.getElementById("ban").style.display = "none";
	}
}

function menu(fl) {
	if(fl>0){
		document.getElementById("menumob").style.display = "block";
	}
	else{
		document.getElementById("menumob").style.display = "none";
	}
}
function submenu(fl) {
	if(fl>0){
		document.getElementById("sub2").style.display = "block";
		document.getElementById("submob").style.display = "block";
		document.getElementById("sub1").style.display = "none";
	}
	else{
		document.getElementById("sub2").style.display = "none";
		document.getElementById("submob").style.display = "none";
		document.getElementById("sub1").style.display = "block";
	}
}
