<?php get_header(); ?>
	<section class="content">
		<div class="container">
			<div class="block1">
			<?php include(TEMPLATEPATH."/top.php");?>
			
<h1>Нумизматика, монеты СССР, юбилейные монеты СССР и России - ussr-coins.ru</h1>
<p>К сожалению страница не найдена</p>
<p><a href="/">Вернуться на главную</a></p>
			<?php include(TEMPLATEPATH."/r_singl.php");?>

			</div>
			<div class="block2">
			<?php include(TEMPLATEPATH."/left.php");?>
			</div>
		</div>
	</section>
<?php get_footer(); ?>